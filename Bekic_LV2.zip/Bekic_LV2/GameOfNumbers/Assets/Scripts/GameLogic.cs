using UnityEngine;
using TMPro;
public class GameLogic : MonoBehaviour
{
    [SerializeField] TextMeshProUGUI guessText;
    int min, max, guess;


    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        min = 1;
        max = 1000;
        GuessNext();
    }
    private void GuessNext()
    {
        guess = Random.Range(min, max);
        guessText.text = guess.ToString();
    }

    public void OnPressHigher()
    {
        min = guess;
        GuessNext();
    }
    public void OnPressLower()
    {
        max = guess;
        GuessNext();
    }
}
